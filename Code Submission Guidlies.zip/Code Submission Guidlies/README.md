Code can be submitted in the last 3 days of the competition. 
Instructions to be declared in a day
